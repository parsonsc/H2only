<section class="hero_banner">
	<div class="inner_content">
        <img src="/h2only/wp-content/themes/h2only/img/header_trans.png" alt="" width="100%">
        <div class="hero_banner_copy">
            <h1>H2Only <img src="/h2only/wp-content/themes/h2only/img/h2_only.png" alt="" width="100%"></h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vel volutpat ante. In hac habitasse platea dictumst.</p>
            <p><strong>ONLY 700 DAYS TO GO</strong></p>
            <a href="#" class="site_cta">Sign up now</a>
        </div>
    </div>
</section>
