<section class="row into_banner full_bg">
    <div class="inner_content">

        <div class="block grid_50 intro_copy">
            <h2>make waves. <strong>save lives.</strong></h2>
            <p>Say farewell to fizzies and juices, bye to beer and ta-ta to tea. Because for two weeks, it’s H2Only.</p>
            <p>Take the challenge and raise money to help our lifesavers at sea; the volunteers who drop everything, day after day, to save lives on the water.</p>
            <p>This is your chance to do something heroic for them.</p>
            <a href="#" class="site_cta">Sign up now</a>
        </div>

        <div class="block grid_50">
            <img src="img/img_01.jpg" alt="">        
        </div>
    </div>
    
</section>
<div class="clear"></div>