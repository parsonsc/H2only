 <section class="social_buttons">
                        <ul id="menu-social" class="menu">
                            <li class="facebook">
                                <a href="http://www.facebook.com/sharer.php?s=100&p[title]=<?php echo urlencode($fbtitle);?>&p[summary]=<?php echo urlencode($fbcopy);?>&p[url]=<?php bloginfo( 'url' ); ?>&p[images][0]=<?php bloginfo( 'url' ); ?>/wp-content/themes/h2only/img/fbook.jpg" title="Facebook">Facebook</a>
                            </li>
                            <li class="twitter">
                                <a href="http://twitter.com/share?text=<?php echo urlencode($twcopy); ?>" title="Twitter" >Twitter</a>
                            </li>
                            <li class="email">
                                <a href="mailto: ?subject=<?php echo str_replace(" ", "%20",$emsubj)?>&body=<?php echo str_replace(" ", "%20",str_replace("<br />", "%0D%0A",nl2br($embody)));?>" title="Email" >Email</a>
                            </li>
                        </ul>
                    </section>     