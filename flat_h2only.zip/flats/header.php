<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css/h2only.css">
        <script src="js/modernizr-2.6.2.min.js"></script>
    </head>
    <body>
        <div id="wrapper">

            <!-- SITE HEADER -->
            <header class="site_header" role="banner">
                <div class="inner_content">
                    <section class="site_logo">
                        <a href="#">
                            <img src="/h2only/wp-content/themes/h2only/img/logo.png" alt="Lifeboats">
                        </a>
                    </section>     
                    
                    <section class="social_buttons">
                        <ul id="menu-social" class="menu">
                            <li class="facebook">
                                <a href="http://www.facebook.com/sharer.php?s=100&p[title]=" title="Facebook">Facebook</a>
                            </li>
                            <li class="twitter">
                                <a href="http://twitter.com/share?text=" title="Twitter" >Twitter</a>
                            </li>
                            <li class="email">
                                <a href="mailto: ?subject=" title="Email" >Email</a>
                            </li>
                        </ul>
                    </section>  
                </div>
            </header>
            <!-- END SITE HEADER -->

            <!-- START HERO BANNER -->
            
       