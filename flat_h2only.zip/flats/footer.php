        <footer class="site_footer">
            <div class="inner_content">

                <section class="footer_nav">
                        <ul class="rnli">
                            <li>
                                <a href="#">
                                    <img src="img/footer_logo.png" alt="Lifeboats">
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="img/footer_h2only.png" alt="">
                                </a>
                            </li>
                        </ul>

                        <ul class="footer_social"> 
                             <li>
                                <a href="#" class="twitter">
                                    FOLLOW @H2OnlyHQ
                                </a>
                            </li>
                            <li>
                                <a href="#" class="facebook">
                                    LIKE US ON FACEBOOK
                                </a>
                            </li>
                        </ul>
                </section>
                <div class="clear"></div>
                <ul class="footer_subnav">
                    <li>
                        <a href="#">H2Only</a>
                    </li>
                    <li>
                        <a href="#">RNLI Lifeboats 2014</a>
                    </li>
                    <li>
                        <a href="#">Terms and conditions apply</a>
                    </li>
                    <li>
                        <a href="#">Read our Privacy policy</a>
                    </li>
                    <li>
                        <a href="#">FAQs</a>
                    </li>
                    <li>                        
                        <img src="img/fsrb.png" alt="">
                    </li>
                </ul>
                <div class="clear"></div>

                <article class="legal">
                    <p>The Royal National Lifeboat Institution is a charity registered in England and Wales (209603) and Scotland (SC037736). 
                    Charity number CHY 2678 in the Republic of Ireland | RNLI (Trading) Ltd - 01073377, RNLI (Sales) Ltd - 2202240, RNLI (Enterprises) Ltd - 
                    1784500 and RNLI College Ltd - 7705470 are all companies registered at West Quay Road, Poole BH15 1HZ. Images &amp; copyright &copy; RNLI 2014. </p>
                </article>

            </div>
        </footer>        

		</div>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery-1.10.2.min.js"><\/script>')</script>
        <script src="js/plugins.js"></script>  
        <script src="js/plug/jquery.meanmenu.2.0.min.js"></script>  
        <script src="js/plug/jquery.meanmenu.js"></script>  
        <script src="js/plug/jquery.postcodes.js"></script>  
        <script src="js/plug/jquery.ui.touch-punch.min.js"></script>  
        <script src="js/plug/jquery.validate.min.js"></script>  
        <script src="js/plug/jquery-easing.1.3.js"></script>  
        <script src="js/plug/jquery-ui-1.10.3.custom.min.js"></script>  
        <script src="js/plug/placeholders.min.js"></script> 
        <script src="js/lib/css3-mediaqueries.js"></script>      
        <script src="js/lib/jquery.nouislider.min.js"></script>       
        <script src="js/lib/selectivizr-1.0.2.min.js"></script>      
        <script src="js/plug/additional-methods.min.js"></script>  
        <script src="js/main.js"></script>   
        
    </body>
</html>