<section class="row top_grid">
    <div class="inner_content">

        <ul>
            <li class="block left">
                <h3>LOREM and <strong>IPSUM</strong></h3>
                <img src="img/img_02.jpg" alt="">  
                <article class="grid_copy">
                    <p>We’ll help you make sure your H2Only challenge is worth every sip, by raising as much money as you can. </p>     
                </article>
                
            </li>
            <li class="block right">
                <h3>LOREM <strong>THE IPSUM?</strong></h3>
                <img src="img/img_03.jpg" alt=""> 
                <article class="grid_copy">
                    <p>If you’re going to drink nothing but water for two weeks, do it in style. Buy your H2Only bottle here.</p> 
                </article>                      
            </li>
        </ul>

    </div>
</section>
<div class="clear"></div>